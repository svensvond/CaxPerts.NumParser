﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaxPerts.NumParser.Model
{
    //results for matching numbers in drawing with "coordinates"
    class FindResult
    {
        public int Number;
        public int Line;
        public int CharPos;
    }
}
